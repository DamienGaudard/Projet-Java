package elements;

public enum Request {

	GO_DOWN,
	GO_LEFT,
	GO_RIGHT,
	GO_TOP,
	SPREAD,
	NONE
	
}
