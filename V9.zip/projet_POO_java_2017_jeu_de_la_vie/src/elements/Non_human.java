package elements;

public abstract class Non_human extends Entity{

	public Non_human(int posX, int posY) {
		super(posX, posY);
	}

}
